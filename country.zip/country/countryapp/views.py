from django.http import response
from django.shortcuts import render
import requests
import bs4
import urllib.parse
import pandas as pd


def home(request):
    return render(request, 'home.html')

def index(request, countryname):
    headings = []
    table_class = "infobox geography vcard"
    if request.method == "POST":
        
        
        countryname = request.POST['countryname']
        url = 'https://en.wikipedia.org/wiki/'
        
        wikiurl = urllib.parse.urljoin(url, countryname)
        wikiresponse = requests.get(wikiurl)
        scrapval = bs4.BeautifulSoup(wikiresponse.text, "html.parser")
        country_details = scrapval.find('table', attrs = {'class': table_class})
        #table_data = country_details.tbody.find_all("tr")
        # for td in table_data[0].find_all("td"):
        #     print("\n\n\n",td)
        #     headings.append(td)    
        df = pd.read_html(str(country_details))
        return render(request, 'countrydata.html', {'df':df,'countryname':countryname})
    else:
        return render(request, 'countrydata.html',{'countryname':countryname})